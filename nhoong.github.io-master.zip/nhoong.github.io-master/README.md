# Nathan Hoong's Engineering Portfolio

This was my first project I started in order to learn basic HTML/CSS and Bootstrap. Updating information on the website every so often.

## Links

 Feel free to contact me or check out my content!

* [LinkedIn](https://www.linkedin.com/in/nhoong/)
